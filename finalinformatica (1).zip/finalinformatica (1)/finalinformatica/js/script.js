
document.getElementById('toggleButton').addEventListener('click', function() {
    const content = document.getElementById('content');
    const button = document.getElementById('toggleButton');
    if (content.style.display === 'none') {
        content.style.display = 'block';
        button.textContent = 'Ver menos';
    } else {
        content.style.display = 'none';
        button.textContent = 'Ver más';
    }
});

document.getElementById('toggleButton1').addEventListener('click', function() {
    const content = document.getElementById('content1');
    const button = document.getElementById('toggleButton1');
    if (content.style.display === 'none') {
        content.style.display = 'block';
        button.textContent = 'Ver menos';
    } else {
        content.style.display = 'none';
        button.textContent = 'Ver más';
    }
});

document.getElementById('toggleButton2').addEventListener('click', function() {
    const content = document.getElementById('content2');
    const button = document.getElementById('toggleButton2');
    if (content.style.display === 'none') {
        content.style.display = 'block';
        button.textContent = 'Ver menos';
    } else {
        content.style.display = 'none';
        button.textContent = 'Ver más';
    }
});

document.getElementById('toggleButton3').addEventListener('click', function() {
    const content = document.getElementById('content3');
    const button = document.getElementById('toggleButton3');
    if (content.style.display === 'none') {
        content.style.display = 'block';
        button.textContent = 'Ver menos';
    } else {
        content.style.display = 'none';
        button.textContent = 'Ver más';
    }
});