//inicio de variables 
let tarjetasDestapadas = 0;
let tarjeta1 = null;
let tarjeta2 = null;
let primerResultado = null;
let segundoResultado = null;
let aciertos = 0
let temporizador = fasle;
let timer =30;
let timerInicial = 30;
let tiempoRegresivoid = null;
//reflejar en el html
let mostarMovimientos = document.getElementById('movimientos')
let mostarAciertos = document.getElementById ('aciertos')
let mostarTiempo = document.getElementById ('t-restante')

//generacion de numeros aleatorios 
let numeros = [ 1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8]
numeros = numeros.sort ( ()=>{return Math.random() -0.5} )
console.log(numeros);

//funciones
function contarTiempo(){
    setInterval(()=>{
        timer--;
        mostrarTiempo.innerHTML = `Tiempo Restante: ${timer} segundos`;
    },1000)
    if (timer == 0){
       clearInterval(tiempoRegresivoid);
    }
}

function bloquearTarjetas(){
    for (let i = 0; i<=15; i++){
        let tarjedaBloqueada = document.getElementById(i)
        tarjetaBloqueada.innerHTML = numeros[i];
        tarjedaBloqueada.disabled = true;
    }
}
//funcion principal
function destapar (id){
    //temporizador 
    if (temporizador == false) {
        contarTiempo();
        temporizador = true;
    }
tarjetasDestapadas++;
console.log(tarjetasDestapadas);

if(tarjetasDestapadas === 1) {
    //mostar el primer numero
tarjeta1 = document.getElementById(id);
primerResultado = numeros[id]
tarjeta1.innerHTML = primerResultado;
//deshabilitar el primer boton
tarjeta1.disabled = true

//mostar segundo numero
tarjeta2 = document.getElementById(id);
segundoResultado = numeros[id];
tarjeta2.innerHTML = segundoResultado;
//deshabilitar el segundo boton
tarjeta2.disabled = true

//incrementar movimientos
movimientos++;
mostrarMovimientos.innerHTML =  `Movimientos: ${movimientos}`


if(primerResultado == segundoResultado) {
    //resetear contador 
    tarjetasDestapadas = 0;
    //mostar aciertos
    mostarAciertos.innerHTML =  `Aciertos: ${aciertos}`

    //deshabilitar una vez que se realizaron todos los aciertos posibles
        if (aciertos == 8) {
            clearInterval(tiempoRegresivoid); //parar el tiempo si ya gano
            //mostar aciertos y mensaje de felicitacion
            mostarAciertos.innerHTML = `Felicitaciones! tuviste todos estos aciertos: ${aciertos}`
            mostarMovimientos.innerHTML =  `Ganaste con todos estos movimientos: ${movimientos}`
            mostarTiempo.innerHTML= `Genial! Solo te tomo: ${timerInicial - timer} segundos`
        }

}
else{
    //volver a mostrar valores y tapar
    setTimeout (()=>{
        tarjeta1.innerHTML = ' ';
        tarjeta2.innerHTML = ' ';
        tarjeta1.disabled = false
        tarjeta2.disabled = false
        tarjetasDestapadas = 0
    },800)
}
}
}